#include <pcap.h>
#include <stdio.h>
#include <netinet/ip.h>
#include <netinet/if_ether.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include "saveinfo.h"

MYSQL *conn;
char *server = "localhost";
char *user = "root";
char *password = "262610"; 
char *database = "mywork";
void net_host(unsigned int ip_mask)
{
  unsigned int one,two,three,four;
  one=ip_mask;
  one=one>>24;
  two=ip_mask;
  two=two>>16;
  two=two&0xff;
  three=ip_mask;
  three=three>>8;
  three=three&0xff;
  four=ip_mask;
  four=four&0xff;
  printf("%u.%u.%u.%u\n",four,three,two,one);
}


void tcp_packet_callback(unsigned char * argument,const struct pcap_pkthdr * pcap_header,const unsigned char * packet_content,char *saddr,char *daddr)
{
  struct tcphdr * tcpptr=(struct tcphdr*)(packet_content+14+20);
  int source_port=ntohs(tcpptr->source);
  int dest_port=ntohs(tcpptr->dest);
  unsigned int seq=ntohl(tcpptr->seq);
  unsigned int ack_seq=ntohl(tcpptr->ack_seq);
  printf("%d,%d,%u,%u\n",source_port,dest_port,seq,ack_seq);
  db_query(conn,"mywork",0,"tcp",source_port,dest_port,saddr,daddr);
}

void udp_packet_callback(unsigned char * argument,const struct pcap_pkthdr * pcap_header,const unsigned char * packet_content,char *saddr,char *daddr)
{
  struct udphdr * udpptr=(struct udphdr*)(packet_content+14+20);
  int source_port=ntohs(udpptr->source);
  int dest_port=ntohs(udpptr->dest);
  db_query(conn,"mywork",0,"udp",source_port,dest_port,saddr,daddr);
}

void ip_packet_callback(unsigned char * argument,const struct pcap_pkthdr * pcap_header,const unsigned char * packet_content)
{
  struct in_addr s,d;
  struct iphdr * ipptr;
  char * saddr=inet_ntoa(ipptr->saddr);
  char * daddr=inet_ntoa(ipptr->daddr);
  ipptr=(struct iphdr*)(packet_content+14);
  //printf("Source address:%s\n",saddr);
  //printf("Destinastion address :%s\n",daddr); 
  switch(ipptr->protocol)
  {
    case 6:
      //tcp
      tcp_packet_callback(argument,pcap_header,packet_content,saddr,daddr);
      break;
    case 1:
      //icmp
      break;
    case 17:
      //udp
      udp_packet_callback(argument,pcap_header,packet_content,saddr,daddr);
      break;
    default:
      break;
  }
}

void ethernet_packet_callback(unsigned char * argument,const struct pcap_pkthdr * pcap_header,const unsigned char * packet_content)
{
  struct ethhdr * ethptr;
  struct iphdr * ipptr;
  unsigned char * mac;
  ethptr=(struct ethhdr*)packet_content;
  mac=ethptr->h_source;
  mac=ethptr->h_dest;

  switch(ntohs(ethptr->h_proto))
  {
    case 0x0800:
      ip_packet_callback(argument,pcap_header,packet_content);
      break;
    default:
      break;
  }
}

int main()
{
  pcap_t * pt;
  char * dev;
  char errbuf[128];
  struct bpf_program fp;
  bpf_u_int32 maskp,netp;
  int ret,i=0,inum;
  int pcap_time_out=5;
  char filter[128];
  unsigned char * packet;
  struct pcap_pkthdr hdr;
  pcap_if_t * alldevs,*d;
  if(pcap_findalldevs(&alldevs,errbuf)==-1)
  {
    fprintf(stderr,"find interface failed!\n");
    return -1;
  }
  for(d=alldevs;d;d=d->next)
  {
    printf("%d,%s\n",++i,d->name);
    if(d->description)
    {
      printf("(%s)",d->description);
    }
    else
    {
      printf("(no description available)\n");
    }
  }
/*
  if(i==0)
	{
		printf("no interface number\n");
		return -1;
	}
  else */if(i==1)
    dev=alldevs->name;
  else
  {
    printf("input a interface:(1-%d)",i);
    scanf("%d",&inum);
    if(inum<1||inum>i)
    {
      printf("interface number out of range\n");
      return -1;
    }
  }

  for(d=alldevs,i=1;i<inum;d=d->next,i++);
  dev=d->name;
  printf("dev:%s\n",dev);
  ret=pcap_lookupnet(dev,&netp,&maskp,errbuf);
  printf("网络号:");
  net_host(netp);
  printf("网络掩码:");
  net_host (maskp); 
  printf("\n");

  if(ret==-1)
  {
    fprintf(stderr,"%s\n",errbuf);
    return -1;
  }
  pt=pcap_open_live(dev,BUFSIZ,1,pcap_time_out,errbuf);
  if(pt==NULL)
  {
    fprintf(stderr,"open error :%s\n",errbuf);
    return -1;
  }

  sprintf(filter,"");
  if(pcap_compile(pt,&fp,filter,0,netp)==-1)
  {
    fprintf(stderr,"set filter error\n");
    return -1;
  }
  conn=db_login(conn,server,user,password,database);
  pcap_loop(pt,-1,ethernet_packet_callback,NULL);
  pcap_close(pt);
  db_close(conn);
  return 0;
}
