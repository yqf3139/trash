#include "saveinfo.h"

int main()
{
   MYSQL *conn;
   char *server = "localhost";
   char *user = "root";
   char *password = "262610"; 
   char *database = "mywork";
   conn=db_login(conn,server,user,password,database);
   db_query(conn,"test",100,"chenbainian");
   db_close(conn);
   return 0;
}
