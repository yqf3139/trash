#include <stdio.h>
#include <mysql.h>

MYSQL * db_login(MYSQL * conn,char *server,char * user,char * password,char * database)
{
  conn=mysql_init(NULL);
  if(!mysql_real_connect(conn,server,user,password,database,0,NULL,0))
  {
    fprintf(stderr,"%s\n",mysql_error(conn));
    return 0;
  }
  return conn;
}

MYSQL * db_query(MYSQL * conn,char * table,int id,char * type,int sour_port,int dest_port,char *saddr,char *daddr)
{
   char query[300];
   sprintf(query,"INSERT INTO %s values (%d,\"%s\",%d,%d,\"%s\",\"%s\")",table,id,type,sour_port,dest_port,saddr,daddr);
   //printf("%s\n",query);
   if(mysql_query(conn,query)!=0)
   {
     return 0;
   }
   else
   {
     return conn;
   }
}


int db_close(MYSQL * conn)
{
  mysql_close(conn);
  return 0;
}

